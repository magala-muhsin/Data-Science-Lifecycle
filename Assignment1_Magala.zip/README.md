# Assignment 1 - Data Science Lifecycle (MSDS-1) - Magala

- Assignment1_Magala.ipynb : executed notebook (code + explanation of every output)
- Magala_Data.csv          : cleaned dataset (201 rows)
- automobileEDA.csv        : original dataset (keep in the same folder to re-run the notebook)

Requires: pandas numpy scipy matplotlib seaborn scikit-learn
